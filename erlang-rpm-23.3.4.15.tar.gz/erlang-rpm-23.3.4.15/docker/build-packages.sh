#!/usr/bin/env sh

./build-image-and-rpm.sh 8 --no-cache
./build-image-and-rpm.sh 7 --no-cache
